# ColabProjects

Python projects using Google Collaboratory for the development of digital image processing and computer vision with Machine Learning courses.